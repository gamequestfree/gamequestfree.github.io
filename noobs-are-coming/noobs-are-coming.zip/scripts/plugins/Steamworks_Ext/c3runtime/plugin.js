
const C3 = globalThis.C3;

C3.Plugins.Steamworks_Ext = class SteamworksExtPlugin extends globalThis.ISDKPluginBase
{
	constructor()
	{
		super();
	}
};
