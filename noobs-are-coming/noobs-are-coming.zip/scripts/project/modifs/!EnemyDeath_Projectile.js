//!revertable ?

export class EnemyDeath_Projectile extends C4.Item_Effect {
	constructor(item, effectName, effectData, parent) {
		super(item, effectName, effectData, parent)
	}

	OnAdded() {
		//
	}

	OnRemoved() {
		//
	}
}
