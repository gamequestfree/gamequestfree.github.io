//!revertable ?

export class Aa extends C4.Item_Effect {
	constructor(item, effectName, effectData, parent) {
		super(item, effectName, effectData, parent)
	}

	OnAdded() {
		//
	}

	OnRemoved() {
		//
	}
}
