export class Compo_ extends C4.Component {
	constructor(unit, data = null) {
		super(unit, data)
	}

	SetData() {
		this.SetVars_Default({
			//
		})
	}

	SetInternals() {
		//
	}

	Init() {
		this._SetTicking(true)
	}

	PostCreate() {
		//
	}
}
