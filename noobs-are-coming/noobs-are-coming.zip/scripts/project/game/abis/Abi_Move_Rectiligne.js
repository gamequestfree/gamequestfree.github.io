export class Abi_Move_Rectiligne extends C4.Abi_Move {
	constructor(unit, abiName, abiData) {
		super(unit, abiName, abiData)
	}

	Init_Data() {
		super.Init_Data()
	}
}
