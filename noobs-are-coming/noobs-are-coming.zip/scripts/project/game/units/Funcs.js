C4.Funcs = class Funcs {
	constructor() {
		this.data = {}
	}
}
